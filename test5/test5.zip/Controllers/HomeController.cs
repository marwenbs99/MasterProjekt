﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using test5.Models;

namespace test5.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        [Authorize]
        
        public ActionResult Index()
        {
            string User_name = "";
           
          
            User_name = Request.Cookies["Mycookie"].Value;
           
            ViewBag.Message = User_name;

            return View();
        }

        [Authorize]
        public ActionResult MyCalendar()
        {
            ViewBag.Message = "Calendar info";

            return View();
        }


        public void AddEvents(Events e)
        {
            using (MyDataBaseEntities dc = new MyDataBaseEntities())
            {
                e.IsFullDay = false;
                e.ThemeColor = "Null";
                dc.Events.Add(e);
                dc.Configuration.ValidateOnSaveEnabled = false;
                dc.SaveChanges();
            
            }
        }

        // string connectionString = @"data source=(LocalDB)\MSSQLLocalDB;attachdbfilename=|DataDirectory|\MyDataBase.mdf;integrated security=True";
        string connectionString = @"workstation id = MSDatabase.mssql.somee.com; packet size = 4096; user id = bensalemarwen_SQLLogin_1; pwd=4zhfkgiwpq;data source = MSDatabase.mssql.somee.com; persist security info=False";
        public JsonResult GetEvents()
        {

            DataTable events = new DataTable();
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                var sqlDa = new SqlDataAdapter("SELECT * FROM Events", sqlCon);
                sqlDa.Fill(events);
                //}

                JavaScriptSerializer serializer = new JavaScriptSerializer();
                List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
                Dictionary<string, object> row;
                foreach (DataRow dr in events.Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (DataColumn col in events.Columns)
                    {
                        row.Add(col.ColumnName, dr[col]);
                    }

                    rows.Add(row);
                }

                return new JsonResult { Data = rows.ToList(), JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
        }





    }
}